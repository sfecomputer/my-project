from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Dict, List, Optional

from .agents import (
    build_planning_agent,
    build_requirement_agent,
    build_risk_agent,
    build_summary_agent,
)
from .llm import LLMClient


@dataclass
class WorkflowStep:
    name: str
    role: str
    output: str


@dataclass
class WorkflowResult:
    requirement: str
    requirement_analysis: str
    task_planning: str
    risk_analysis: str
    final_summary: str
    steps: List[WorkflowStep]
    created_at: str

    def to_dict(self) -> Dict:
        data = asdict(self)
        return data

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


class MultiAgentWorkflow:
    def __init__(self, llm: Optional[LLMClient] = None):
        self.llm = llm or LLMClient()
        self.requirement_agent = build_requirement_agent(self.llm)
        self.planning_agent = build_planning_agent(self.llm)
        self.risk_agent = build_risk_agent(self.llm)
        self.summary_agent = build_summary_agent(self.llm)

    def run(self, requirement: str) -> WorkflowResult:
        requirement = requirement.strip()
        if not requirement:
            raise ValueError("需求内容不能为空。")

        steps: List[WorkflowStep] = []

        requirement_analysis = self.requirement_agent.run(requirement)
        steps.append(
            WorkflowStep(
                name=self.requirement_agent.name,
                role=self.requirement_agent.role,
                output=requirement_analysis,
            )
        )

        planning_input = f"""
原始需求：
{requirement}

需求分析结果：
{requirement_analysis}
""".strip()
        task_planning = self.planning_agent.run(planning_input)
        steps.append(
            WorkflowStep(
                name=self.planning_agent.name,
                role=self.planning_agent.role,
                output=task_planning,
            )
        )

        risk_input = f"""
原始需求：
{requirement}

需求分析结果：
{requirement_analysis}

任务拆解结果：
{task_planning}
""".strip()
        risk_analysis = self.risk_agent.run(risk_input)
        steps.append(
            WorkflowStep(
                name=self.risk_agent.name,
                role=self.risk_agent.role,
                output=risk_analysis,
            )
        )

        summary_input = f"""
原始需求：
{requirement}

需求分析结果：
{requirement_analysis}

任务拆解结果：
{task_planning}

风险评估结果：
{risk_analysis}
""".strip()
        final_summary = self.summary_agent.run(summary_input)
        steps.append(
            WorkflowStep(
                name=self.summary_agent.name,
                role=self.summary_agent.role,
                output=final_summary,
            )
        )

        return WorkflowResult(
            requirement=requirement,
            requirement_analysis=requirement_analysis,
            task_planning=task_planning,
            risk_analysis=risk_analysis,
            final_summary=final_summary,
            steps=steps,
            created_at=datetime.now().isoformat(timespec="seconds"),
        )
