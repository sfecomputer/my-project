from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .llm import LLMClient


@dataclass
class Agent:
    name: str
    role: str
    system_prompt: str
    llm: LLMClient
    temperature: float = 0.2

    def run(self, user_input: str) -> str:
        return self.llm.chat(
            system_prompt=self.system_prompt,
            user_prompt=user_input,
            temperature=self.temperature,
        )


def build_requirement_agent(llm: LLMClient) -> Agent:
    return Agent(
        name="RequirementAgent",
        role="需求理解 Agent",
        llm=llm,
        system_prompt="""
你是一个资深产品需求分析师。你的任务是分析用户输入的产品需求。
请只输出合法 JSON，不要输出 Markdown。
JSON 字段必须包含：
1. 核心目标
2. 用户角色
3. 关键功能点
4. 隐含需求
5. 验收标准
""".strip(),
    )


def build_planning_agent(llm: LLMClient) -> Agent:
    return Agent(
        name="PlanningAgent",
        role="任务拆解 Agent",
        llm=llm,
        system_prompt="""
你是一个资深技术项目经理。你的任务是根据需求分析结果拆解开发任务。
请只输出合法 JSON，不要输出 Markdown。
JSON 字段必须包含：
1. 前端任务
2. 后端任务
3. 数据库任务
4. 测试任务
5. 里程碑
每个任务尽量包含：任务、优先级、预计工作量。
""".strip(),
    )


def build_risk_agent(llm: LLMClient) -> Agent:
    return Agent(
        name="RiskAgent",
        role="风险评估 Agent",
        llm=llm,
        system_prompt="""
你是一个资深架构师和风险评估专家。你的任务是识别项目中的技术风险、产品风险和交付风险。
请只输出合法 JSON，不要输出 Markdown。
JSON 字段必须包含：风险列表。
每个风险项必须包含：风险点、风险等级、影响范围、解决建议。
""".strip(),
    )


def build_summary_agent(llm: LLMClient) -> Agent:
    return Agent(
        name="SummaryAgent",
        role="汇总决策 Agent",
        llm=llm,
        temperature=0.3,
        system_prompt="""
你是一个项目负责人。你的任务是综合需求分析、任务拆解和风险评估结果，输出最终项目执行方案。
请使用 Markdown 输出，结构必须包含：
1. 项目目标
2. 核心功能
3. 开发计划
4. 风险与应对方案
5. 可量化价值
语言要专业、具体、可用于项目申报或绩效材料。
""".strip(),
    )
