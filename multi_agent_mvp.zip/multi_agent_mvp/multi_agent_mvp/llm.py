from __future__ import annotations

import json
from typing import Optional

from .config import Settings, get_settings


class LLMClient:
    """LLM 封装层。

    - USE_MOCK_LLM=1：返回固定但结构完整的结果，便于本地演示和面试展示。
    - USE_MOCK_LLM=0：调用 OpenAI/兼容 OpenAI SDK 的模型服务。
    """

    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or get_settings()
        self._client = None

        if not self.settings.use_mock_llm:
            if not self.settings.openai_api_key:
                raise RuntimeError("OPENAI_API_KEY 未配置。可先将 USE_MOCK_LLM=1 跑通本地演示。")
            try:
                from openai import OpenAI
            except ImportError as exc:
                raise RuntimeError("未安装 openai 包。请先运行：pip install -r requirements.txt") from exc

            kwargs = {"api_key": self.settings.openai_api_key}
            if self.settings.openai_base_url:
                kwargs["base_url"] = self.settings.openai_base_url
            self._client = OpenAI(**kwargs)

    def chat(self, *, system_prompt: str, user_prompt: str, temperature: float = 0.2) -> str:
        if self.settings.use_mock_llm:
            return self._mock_response(system_prompt=system_prompt, user_prompt=user_prompt)

        response = self._client.chat.completions.create(
            model=self.settings.openai_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content or ""

    def _mock_response(self, *, system_prompt: str, user_prompt: str) -> str:
        prompt = f"{system_prompt}\n{user_prompt}"

        # 顺序很重要：后续 Agent 的输入会包含前序 Agent 的关键词，必须先判断更具体的角色。
        if "项目负责人" in system_prompt or "最终项目执行方案" in system_prompt:
            return """# 最终项目执行方案

## 1. 项目目标
构建一个多 Agent 协作的智能需求管理 MVP，将自然语言需求自动转化为需求分析、任务拆解、风险评估和执行计划。

## 2. 核心功能
- 需求理解 Agent：提炼目标、用户、功能点、隐含需求和验收标准。
- 任务拆解 Agent：输出前端、后端、数据库和测试任务。
- 风险评估 Agent：识别技术、产品和交付风险，并给出应对建议。
- 汇总决策 Agent：生成可直接用于评审的 Markdown 项目方案。

## 3. MVP 开发计划
第一周完成端到端流程、Web UI、JSON/Markdown 导出和 mock 演示模式；第二周接入真实模型、历史记录和权限控制。

## 4. 风险与应对
主要风险包括输出不稳定、上下文不足和 token 成本偏高。建议通过 Schema 校验、澄清问题流程、缓存和摘要压缩降低风险。

## 5. 可量化价值
该系统可将需求评审准备时间从约 2 小时降低到 20 分钟内，减少 50% 以上重复沟通，并通过缓存与摘要策略降低约 30% token 消耗。
"""

        if "风险评估" in system_prompt or "架构师" in system_prompt:
            return json.dumps(
                {
                    "风险列表": [
                        {
                            "风险点": "LLM 输出不稳定，影响任务拆解一致性",
                            "风险等级": "高",
                            "影响范围": "项目计划准确性",
                            "解决建议": "增加 JSON Schema 校验、失败重试和人工确认步骤",
                        },
                        {
                            "风险点": "需求上下文不足导致误判",
                            "风险等级": "中",
                            "影响范围": "需求分析质量",
                            "解决建议": "引入澄清问题 Agent，在关键信息缺失时先提问再拆解",
                        },
                        {
                            "风险点": "token 成本随需求长度增加",
                            "风险等级": "中",
                            "影响范围": "运行成本",
                            "解决建议": "加入摘要压缩、缓存和分层模型调用策略",
                        },
                    ]
                },
                ensure_ascii=False,
                indent=2,
            )

        if "技术项目经理" in system_prompt or "拆解开发任务" in system_prompt:
            return json.dumps(
                {
                    "前端任务": [
                        {"任务": "需求录入与结果展示页面", "优先级": "P0", "工作量": "2 人日"},
                        {"任务": "历史需求检索与筛选", "优先级": "P1", "工作量": "2 人日"},
                    ],
                    "后端任务": [
                        {"任务": "Agent 编排接口", "优先级": "P0", "工作量": "3 人日"},
                        {"任务": "导出 Markdown/JSON", "优先级": "P1", "工作量": "1 人日"},
                    ],
                    "数据库任务": [
                        {"任务": "需求、任务、风险结果表设计", "优先级": "P0", "工作量": "1 人日"},
                        {"任务": "历史结果索引", "优先级": "P1", "工作量": "1 人日"},
                    ],
                    "测试任务": [
                        {"任务": "核心流程冒烟测试", "优先级": "P0", "工作量": "1 人日"},
                        {"任务": "异常输入与超时测试", "优先级": "P1", "工作量": "1 人日"},
                    ],
                    "里程碑": [
                        {"阶段": "MVP", "周期": "1 周", "目标": "跑通端到端 Agent 工作流"},
                        {"阶段": "Beta", "周期": "2 周", "目标": "接入权限、历史检索和导出"},
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )

        if "需求分析" in system_prompt or "产品需求分析师" in system_prompt:
            return json.dumps(
                {
                    "核心目标": "将自然语言产品需求自动转化为可执行项目方案",
                    "用户角色": ["产品经理", "研发负责人", "测试人员"],
                    "关键功能点": [
                        "自然语言需求录入",
                        "需求结构化分析",
                        "任务自动拆解",
                        "风险识别与建议",
                        "项目计划导出",
                    ],
                    "隐含需求": ["权限控制", "历史需求复用", "结果可追溯", "与现有研发流程集成"],
                    "验收标准": [
                        "输入一段需求后 30 秒内生成完整方案",
                        "输出包含功能列表、任务拆解、风险和里程碑",
                        "支持 Markdown/JSON 导出",
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )

        return ""
