import json
from pathlib import Path

import streamlit as st

from multi_agent_mvp.config import get_settings
from multi_agent_mvp.workflow import MultiAgentWorkflow


st.set_page_config(
    page_title="多 Agent 需求管理 MVP",
    page_icon="🤖",
    layout="wide",
)

DEFAULT_REQUIREMENT = """我们要做一个企业内部智能需求管理系统。
用户可以输入自然语言需求，系统自动分析需求内容，拆解开发任务，评估风险，并生成项目计划。
系统主要服务产品经理、研发负责人和测试人员。
需要支持历史需求检索、任务优先级排序、风险提醒和项目计划导出。"""


st.title("🤖 多 Agent 需求分析与任务拆解 MVP")
st.caption("需求理解 Agent → 任务拆解 Agent → 风险评估 Agent → 汇总决策 Agent")

settings = get_settings()
with st.sidebar:
    st.header("运行配置")
    st.write("Mock 模式：", "✅ 开启" if settings.use_mock_llm else "❌ 关闭")
    st.write("模型：", settings.openai_model)
    st.info(
        "首次演示建议使用 USE_MOCK_LLM=1，无需 API Key 即可完整跑通。"
        "接入真实模型时，将 .env 中 USE_MOCK_LLM 改为 0 并配置 OPENAI_API_KEY。"
    )

requirement = st.text_area(
    "输入产品需求",
    value=DEFAULT_REQUIREMENT,
    height=220,
    help="可以输入自然语言需求、PRD 摘要或业务目标。",
)

col1, col2 = st.columns([1, 4])
with col1:
    run_btn = st.button("开始运行", type="primary", use_container_width=True)

if run_btn:
    try:
        with st.status("多 Agent 工作流运行中...", expanded=True) as status:
            st.write("1. 需求理解 Agent 正在分析需求...")
            workflow = MultiAgentWorkflow()
            result = workflow.run(requirement)
            st.write("2. 任务拆解 Agent 已生成开发计划。")
            st.write("3. 风险评估 Agent 已识别风险。")
            st.write("4. 汇总决策 Agent 已输出最终方案。")
            status.update(label="运行完成", state="complete")

        st.success("多 Agent 工作流执行完成")

        tab1, tab2, tab3, tab4, tab5 = st.tabs(
            ["最终方案", "需求分析", "任务拆解", "风险评估", "完整 JSON"]
        )

        with tab1:
            st.markdown(result.final_summary)

        with tab2:
            st.code(result.requirement_analysis, language="json")

        with tab3:
            st.code(result.task_planning, language="json")

        with tab4:
            st.code(result.risk_analysis, language="json")

        with tab5:
            output_json = result.to_json()
            st.download_button(
                "下载结果 JSON",
                data=output_json.encode("utf-8"),
                file_name="multi_agent_result.json",
                mime="application/json",
            )
            st.code(output_json, language="json")

    except Exception as exc:
        st.error(f"运行失败：{exc}")
        st.warning("如果还没有配置 API Key，请先在 .env 中设置 USE_MOCK_LLM=1 跑通演示。")
else:
    st.markdown(
        """
### 这个 MVP 能做什么
- 输入一段产品需求。
- 需求理解 Agent 自动提炼目标、用户、功能点和验收标准。
- 任务拆解 Agent 自动生成前端、后端、数据库、测试任务和里程碑。
- 风险评估 Agent 自动识别技术、产品、交付风险。
- 汇总决策 Agent 输出可用于评审/申报/绩效材料的项目方案。

点击 **开始运行** 查看端到端效果。
"""
    )
