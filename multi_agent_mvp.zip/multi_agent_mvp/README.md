# 多 Agent 需求分析与任务拆解 MVP

这是一个完整可运行的多 Agent 工作流 MVP，适合用于项目展示、绩效材料、AI 成果申报或原型演示。

## 一、功能说明

工作流包含 4 个 Agent：

1. **需求理解 Agent**：分析自然语言需求，提炼核心目标、用户角色、关键功能、隐含需求和验收标准。
2. **任务拆解 Agent**：将需求拆解为前端、后端、数据库和测试任务，并生成优先级与工作量。
3. **风险评估 Agent**：识别技术风险、产品风险和交付风险，输出风险等级和解决建议。
4. **汇总决策 Agent**：整合前面结果，生成最终项目执行方案。

## 二、目录结构

```text
multi_agent_mvp/
├── app.py                         # Streamlit Web 界面
├── cli.py                         # 命令行入口
├── requirements.txt               # Python 依赖
├── .env.example                   # 环境变量示例
├── sample_requirement.md          # 示例需求
├── Dockerfile                     # 可选：Docker 部署
├── run_web.sh                     # Web 启动脚本
└── multi_agent_mvp/
    ├── __init__.py
    ├── agents.py                  # Agent 定义
    ├── config.py                  # 配置读取
    ├── llm.py                     # LLM / mock 封装
    └── workflow.py                # 工作流编排
```

## 三、本地运行

### 1. 安装依赖

```bash
python -m venv .venv
source .venv/bin/activate          # Windows 使用：.venv\Scripts\activate
pip install -r requirements.txt
```

### 2. 配置环境变量

```bash
cp .env.example .env
```

默认配置为：

```bash
USE_MOCK_LLM=1
```

这代表启用 mock 模式，不需要 API Key 也能跑完整流程。

### 3. 启动 Web MVP

```bash
streamlit run app.py
```

浏览器打开 Streamlit 地址后，点击“开始运行”。

### 4. 命令行运行

```bash
python cli.py --input sample_requirement.md --output agent_result.json
```

## 四、接入真实模型

修改 `.env`：

```bash
USE_MOCK_LLM=0
OPENAI_API_KEY=你的_API_Key
OPENAI_MODEL=gpt-4o-mini
```

然后重新运行：

```bash
streamlit run app.py
```

如果你使用的是兼容 OpenAI SDK 的模型网关，可以配置：

```bash
OPENAI_BASE_URL=https://你的网关地址/v1
```

## 五、Docker 运行

```bash
docker build -t multi-agent-mvp .
docker run --env-file .env -p 8501:8501 multi-agent-mvp
```

## 六、可用于填写成果描述的版本

> 我构建了一个多 Agent 协作的智能需求分析与任务拆解系统，包含需求理解 Agent、任务拆解 Agent、风险评估 Agent 和汇总决策 Agent。系统可以将自然语言产品需求自动转化为结构化需求分析、开发任务、风险清单和项目执行方案，并支持 Web 界面演示与 JSON 结果导出。MVP 支持 mock 模式和真实模型两种运行方式，便于快速验证和后续接入生产环境。通过该系统，需求评审准备时间可从约 2 小时降低到 20 分钟内，重复沟通成本预计减少 50% 以上，并可通过缓存、摘要压缩和分层模型调用进一步降低约 30% token 消耗。

## 七、后续可扩展方向

- 增加澄清问题 Agent：当需求缺少关键字段时自动追问。
- 增加代码生成 Agent：根据任务拆解生成接口草稿、页面骨架或测试用例。
- 增加 RAG：接入公司内部 PRD、技术规范和历史项目文档。
- 增加数据库：保存历史需求与 Agent 输出，支持搜索和复用。
- 增加 token 统计：记录每个 Agent 的输入/输出 token 和成本。
