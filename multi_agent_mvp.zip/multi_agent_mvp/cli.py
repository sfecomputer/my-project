import argparse
from pathlib import Path

from multi_agent_mvp.workflow import MultiAgentWorkflow


def main() -> None:
    parser = argparse.ArgumentParser(description="多 Agent 需求分析与任务拆解 MVP")
    parser.add_argument("--input", "-i", type=str, default="sample_requirement.md", help="需求文件路径")
    parser.add_argument("--output", "-o", type=str, default="agent_result.json", help="输出 JSON 路径")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        raise FileNotFoundError(f"找不到输入文件：{input_path}")

    requirement = input_path.read_text(encoding="utf-8")
    workflow = MultiAgentWorkflow()
    result = workflow.run(requirement)

    output_path = Path(args.output)
    output_path.write_text(result.to_json(), encoding="utf-8")

    print("\n========== 最终项目方案 ==========")
    print(result.final_summary)
    print(f"\n完整结果已保存：{output_path.resolve()}")


if __name__ == "__main__":
    main()
